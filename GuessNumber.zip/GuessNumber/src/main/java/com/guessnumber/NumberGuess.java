package com.guessnumber;

import java.io.IOException;
import java.util.Random;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/guess")
public class NumberGuess extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final int MAX_GUESSES = 5;
    private int randomNumber;
    private int numOfGuesses;

    @Override
    public void init() throws ServletException {
        resetGame();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle new game initialization
        resetGame();
        sendInitialForm(response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String guessParam = request.getParameter("guess");
        int guess = 0;
        String message;
        String messageStyle = "message";

        try {
            if (guessParam == null || guessParam.isEmpty()) {
                throw new NumberFormatException("Null or empty guess parameter");
            }
            guess = Integer.parseInt(guessParam);
            if (guess < 1 || guess > 10) {
                throw new NumberFormatException("Guess out of range");
            }
        } catch (NumberFormatException e) {
            message = "Invalid input. Please enter a valid number.";
            sendResponse(response, message, messageStyle, false);
            return;
        }

        boolean gameOver = false;
        if (guess == randomNumber) {
            message = "Congratulations! You guessed the number, which is " + randomNumber + ".";
            gameOver = true;
        } else {
            numOfGuesses--;
            if (numOfGuesses == 0) {
                message = "Sorry, you've run out of guesses. The number was " + randomNumber + ".";
                gameOver = true;
            } else {
                message = "Incorrect guess. You have " + numOfGuesses + " guesses left.";
                messageStyle = "message incorrect";
            }
        }

        sendResponse(response, message, messageStyle, gameOver);
        if (gameOver) {
            resetGame();
        }
    }

    private void resetGame() {
        Random random = new Random();
        randomNumber = random.nextInt(10) + 1;
        numOfGuesses = MAX_GUESSES;
    }

    private void sendInitialForm(HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.getWriter().println("<html><head><title>Guess a Number</title>");
        response.getWriter().println("<link rel='stylesheet' type='text/css' href='Style.css'>");
        response.getWriter().println("</head><body>");
        response.getWriter().println("<br><br><center><h1 style='color:rgb(52, 199, 150)'>Guess a Number</h1></center>");
        response.getWriter().println("<center><form action='guess' method='post'>");
        response.getWriter().println("<div class='col'>");
        response.getWriter().println("<label for='guess'>Enter a Number(1-10):</label>");
        response.getWriter().println("<input type='number' name='guess' id='guess' required class='box'><br><br>");
        response.getWriter().println("<input type='submit' value='Submit' class='sub'></div>");
        response.getWriter().println("</form></center>");
        response.getWriter().println("</body></html>");
    }

    private void sendResponse(HttpServletResponse response, String message, String messageStyle, boolean gameOver) throws IOException {
        response.setContentType("text/html");
        response.getWriter().println("<html><head><title>Guess Result</title>");
        response.getWriter().println("<link rel='stylesheet' type='text/css' href='Style.css'>");
        response.getWriter().println("</head><body>");
        response.getWriter().println("<div class='col'>");
        response.getWriter().println("<div class='" + messageStyle + "'><h1>" + message + "</h1></div>");
        if (gameOver) {
            response.getWriter().println("<form action='guess' method='get'>");
            response.getWriter().println("<input type='submit' value='New Game' class='sub'>");
            response.getWriter().println("</form>");
        } else {
            response.getWriter().println("<a href='Index.html'>Try Again</a>");
        }
        response.getWriter().println("</div></body></html>");
    }
}
